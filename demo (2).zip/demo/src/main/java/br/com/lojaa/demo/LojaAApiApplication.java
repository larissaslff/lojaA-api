package br.com.lojaa.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaAApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaAApiApplication.class, args);
	}

}
